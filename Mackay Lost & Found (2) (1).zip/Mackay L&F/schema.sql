-- ============================================================
--  The Mackay School · Objetos Perdidos y Encontrados
--  Esquema Fase 2 (Supabase / PostgreSQL)
-- ============================================================

create table if not exists public.items (
  id          uuid primary key default gen_random_uuid(),
  name        text not null check (char_length(name) between 1 and 120),
  category    text not null check (category in ('Ropa','Calzado','Accesorios','Otros')),
  where_found text not null check (char_length(where_found) between 1 and 120),
  left_at     text not null check (char_length(left_at) between 1 and 120),
  contact     text          check (char_length(coalesce(contact,'')) <= 80),
  resolved    boolean not null default false,
  created_at  timestamptz not null default now(),
  resolved_at timestamptz
);

create index if not exists items_active_idx  on public.items (resolved, created_at desc);
create index if not exists items_category_idx on public.items (category);

-- Marca automáticamente la fecha de resolución
create or replace function public.set_resolved_at()
returns trigger language plpgsql as $$
begin
  if new.resolved = true and (old.resolved is distinct from true) then
    new.resolved_at := now();
  elsif new.resolved = false then
    new.resolved_at := null;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_resolved_at on public.items;
create trigger trg_resolved_at
  before update on public.items
  for each row execute function public.set_resolved_at();

-- ============================================================
--  Row Level Security (tablón público, sin login)
-- ============================================================
alter table public.items enable row level security;

-- Cualquiera puede VER las publicaciones
drop policy if exists "lectura publica" on public.items;
create policy "lectura publica"
  on public.items for select
  to anon, authenticated
  using (true);

-- Cualquiera puede PUBLICAR un objeto encontrado
drop policy if exists "publicar objeto" on public.items;
create policy "publicar objeto"
  on public.items for insert
  to anon, authenticated
  with check (resolved = false);

-- Cualquiera puede MARCAR como resuelto (no se permite borrar)
drop policy if exists "marcar resuelto" on public.items;
create policy "marcar resuelto"
  on public.items for update
  to anon, authenticated
  using (true)
  with check (true);

-- (DELETE queda sin policy => nadie puede borrar desde el cliente.
--  La moderación de inspectoría se hará en una Fase 4 con login.)

-- ============================================================
--  Datos de ejemplo (puedes borrarlos cuando quieras)
-- ============================================================
insert into public.items (name, category, where_found, left_at, contact, resolved, created_at) values
  ('Chaqueta de buzo azul Mackay', 'Ropa',        'Cancha de fútbol',   'Inspectoría',          '',           false, now() - interval '1 day'),
  ('Estuche negro con lápices',    'Accesorios',  'Sala 7°B',           'Conserjería',          'Prof. Rojas',false, now() - interval '2 day'),
  ('Zapatilla deportiva blanca',   'Calzado',     'Camarines gimnasio', 'Recepción gimnasio',   '',           true,  now() - interval '3 day'),
  ('Botella metálica verde',       'Otros',       'Comedor',            'Conserjería',          '',           false, now() - interval '5 hour');
