-- ============================================================
--  Mackay Lost & Found · Soporte de FOTOS (Storage)
--  Correr DESPUÉS de schema.sql, en el SQL Editor.
-- ============================================================

-- 1) Columna para guardar la URL pública de la foto
alter table public.items
  add column if not exists image_url text;

-- 2) Bucket público para las fotos de los objetos
insert into storage.buckets (id, name, public)
values ('objetos', 'objetos', true)
on conflict (id) do update set public = true;

-- 3) Políticas de Storage
--    Lectura pública (el bucket es público, pero lo dejamos explícito)
drop policy if exists "fotos lectura publica" on storage.objects;
create policy "fotos lectura publica"
  on storage.objects for select
  to anon, authenticated
  using (bucket_id = 'objetos');

--    Cualquiera puede SUBIR una foto al bucket 'objetos'
drop policy if exists "fotos subida publica" on storage.objects;
create policy "fotos subida publica"
  on storage.objects for insert
  to anon, authenticated
  with check (bucket_id = 'objetos');

-- (No damos update/delete a anon: las fotos no se pueden borrar
--  desde el cliente. Limpieza/moderación = Fase 4 con login.)
